/* 
 * File:   main.cpp
 * Author: Connor Smith
 * Created on March 7, 2017, 12:01 PM
 * Purpose:  Calculate # of Candy Bars
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare and initalize variables
    char sex;                   //M or F
    unsigned short ht,wt,age;   //Height inches, Weight pounds, Age years
    unsigned char cndyCal=230;  //Candy Bar Calories
    float bmr;                  //Basic Metabolic Rate (Calories)
    int nCdyBrs;               //Number of Candy bars
    //Input data
    
    cout<<"This program calculates the number of candy bars allowed per day"<<endl;
    cout<<"based on your BMR"<<endl;
    cout<<"Type in your Sex(M/F), Weight (lbs), Height(ht), Age(yrs)"<<endl;
    cout<<"Inputs are intger based"<<endl;
    cin>>sex>>wt>>ht>>age;
    
    //Map inputs to outputs or process the data
    bmr=(sex=='M')?
        66 + 6.3f*wt + 12.9f*ht - 6.8f*age:
       655 + 4.3f*wt +  4.7f*ht - 4.7f*age;
    nCdyBrs=static_cast<int>(bmr/cndyCal);
    
    //Output the transformed data
    cout<<"The number of candy bars you can eat = "<<nCdyBrs<<endl;
    //Exit stage right!
    return 0;
}

